from setuptools import setup
from setuptools.extension import Extension


setup(name = 'severed_bindings',
      version = '1.0',
      author = 'Fraunhofer AISEC',
      author_email = 'erick.quintanar.salas@aisec.fraunhofer.de',
      url = 'https://github.com/Fraunhofer-AISEC/severed-framework/',
      ext_modules = [Extension('severed_bindings', ['SeveredPythonModule/severed_module_def.c'])]
     )
