#include <linux/kvm.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#include <Python.h>

typedef struct ma_mapping_change_param {
    uint64_t gfn1;
    uint64_t gfn2;
    pid_t pid;
} ma_mapping_change_param_t;

typedef struct mapping_change_param2 {
    __u64 gfn;
    __u64 pfn;
    pid_t pid;
} mapping_change_param2_t;

typedef struct irq_no {
    int irq_no;
    pid_t pid;
} irq_no_t;

typedef struct translate_gfn {
    __u64 gfn;
    pid_t pid;
} translate_gfn_t;

#define KVMIO 0xAE
#define KVM_TRACKING_ENABLE       _IOWR(KVMIO, 0x0b, unsigned)
#define KVM_TRACKING_DISABLE      _IO(KVMIO,   0x0c)
#define KVM_MAPPING_CHANGE        _IOWR(KVMIO, 0x0d, ma_mapping_change_param_t)
#define KVM_FIND_INT_HANDLER      _IOWR(KVMIO, 0x0e, int)
#define KVM_SET_ACCESS_ID         _IOWR(KVMIO, 0x0f, int)
#define KVM_SET_VIRTIO_TRACKING   _IOWR(KVMIO, 0x10, int)
#define KVM_PRINT_BUF 		      _IO(KVMIO, 0x11)
#define KVM_GET_PFN 			  _IOWR(KVMIO, 0x12, unsigned long long)
#define KVM_ISSUE_NMI    		  _IO(KVMIO, 0x14)
#define KVM_MAPPING_CHANGE_DIRECT       _IOWR(KVMIO, 0x15, mapping_change_param2_t)

#define KVM_CONSTANT(m, x) PyModule_AddIntConstant(m, #x, x);

static PyObject *severed_change_mapping(PyObject *self, PyObject *args);
static PyObject *severed_disable_tracking(PyObject *self, PyObject *args);
static PyObject *severed_enable_tracking(PyObject *self, PyObject *args);
static PyObject *severed_find_int_handler(PyObject *self, PyObject *args);
static PyObject *severed_set_access_id(PyObject *self, PyObject *args);
static PyObject *severed_set_virtio_track(PyObject *self, PyObject *args);
static PyObject *severed_translate_gfn(PyObject *self, PyObject *args);
static PyObject *severed_issue_nmi(PyObject *self, PyObject *args);
static PyObject *severed_print_buffer(PyObject *self, PyObject *args);
static PyObject *severed_change_mapping_direct(PyObject *self, PyObject *args);

static PyMethodDef module_methods[] = {
    { "severed_enable_tracking",    severed_enable_tracking,    METH_VARARGS, "Enable page tracking"},
    { "severed_disable_tracking",   severed_disable_tracking,   METH_VARARGS, "Disable page tracking"},
    { "severed_change_mapping",     severed_change_mapping,     METH_VARARGS, "Change page mapping of two GFNs in SLAT"},
    { "severed_find_int_handler",   severed_find_int_handler,   METH_VARARGS, "Start search of interrupt handler in guest"},
    { "severed_set_access_id",      severed_set_access_id,      METH_VARARGS, "Set the access identifier used in prints"},
    { "severed_set_virtio_track",   severed_set_virtio_track,   METH_VARARGS, "Enable/Disable virtio tracking"},
    { "severed_translate_gfn",      severed_translate_gfn,      METH_VARARGS, "Translate a given GFN to a PFN"},
    { "severed_issue_nmi",          severed_issue_nmi,          METH_VARARGS, "Send an NMI to the guest VM"},
    { "severed_print_buffer",       severed_print_buffer,       METH_VARARGS, "Print the tracked pages in the buffer"},
    { "severed_change_mapping_direct",    severed_change_mapping_direct,    METH_VARARGS, "Change mapping of a GFN to a specific PFN in SLAT"},
    { NULL, NULL, 0, NULL }
};

static struct PyModuleDef severed_module = {
    PyModuleDef_HEAD_INIT,
    "severed",
    "Python3 module for communication with KVM/SEVered functions",
    -1,
    module_methods
};

PyMODINIT_FUNC PyInit_severed_bindings(void)
{
    PyObject *mod = PyModule_Create(&severed_module);

    KVM_CONSTANT(mod, KVM_GET_API_VERSION);
    KVM_CONSTANT(mod, KVM_TRACKING_ENABLE);
    KVM_CONSTANT(mod, KVM_TRACKING_DISABLE);
    KVM_CONSTANT(mod, KVM_MAPPING_CHANGE);
    KVM_CONSTANT(mod, KVM_FIND_INT_HANDLER);
    KVM_CONSTANT(mod, KVM_SET_VIRTIO_TRACKING);
    KVM_CONSTANT(mod, KVM_PRINT_BUF);
    KVM_CONSTANT(mod, KVM_GET_PFN);
    KVM_CONSTANT(mod, KVM_ISSUE_NMI);
    KVM_CONSTANT(mod, KVM_MAPPING_CHANGE_DIRECT);

    return mod;
}

static int __severed_kvmioctl(int ioctl_num, void *argument) {
    int fd = -1, ret = -1;

    if((fd = open("/dev/kvm", O_RDWR | O_CLOEXEC)) == -1) {
        PyErr_Format(
            PyExc_Exception,
            "Could not open file '/dev/kvm'. Error: %d",
            fd
        );
        return -1;
    }

    ret = ioctl(fd, ioctl_num, argument, NULL);
    close(fd);

    return ret;
}

static PyObject *severed_issue_nmi(PyObject *self, PyObject *args)
{
    int ret = -1;

    int pid;

    if (!PyArg_ParseTuple(args, "i", &pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_ISSUE_NMI, &pid);

    return Py_BuildValue("i", ret);
}

static PyObject *severed_print_buffer(PyObject *self, PyObject *args)
{
    int ret = -1;

    ret = __severed_kvmioctl(KVM_PRINT_BUF, NULL);

    return Py_BuildValue("i", ret);
}

static PyObject *severed_translate_gfn(PyObject *self, PyObject *args)
{
    translate_gfn_t severed_translate_gfn;
    int ret;

    if (!PyArg_ParseTuple(args, "Ki", &severed_translate_gfn.gfn, &severed_translate_gfn.pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_GET_PFN, &severed_translate_gfn);

    return Py_BuildValue("i", ret);
}

static PyObject *severed_set_virtio_track(PyObject *self, PyObject *args)
{
    int ret = -1;
    unsigned long enabled = 0;

    if (!PyArg_ParseTuple(args, "i", &enabled)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_SET_VIRTIO_TRACKING, &enabled);

    return Py_BuildValue("i", ret);
}

static PyObject *severed_set_access_id(PyObject *self, PyObject *args)
{
    int ret = -1;
    int access_id;

    if (!PyArg_ParseTuple(args, "I", &access_id)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_SET_ACCESS_ID, &access_id);
    return Py_BuildValue("i", ret);
}

static PyObject *severed_find_int_handler(PyObject *self, PyObject *args)
{
    int ret = -1;
    irq_no_t severed_irq_no;

    if (!PyArg_ParseTuple(args, "ii", &severed_irq_no.irq_no, &severed_irq_no.pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_FIND_INT_HANDLER, &severed_irq_no);
    return Py_BuildValue("i", ret);
}

static PyObject *severed_enable_tracking(PyObject *self, PyObject *args)
{
    int ret = -1;
    int pid;

    if (!PyArg_ParseTuple(args, "i", &pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_TRACKING_ENABLE, &pid);
    return Py_BuildValue("i", ret);
}

static PyObject *severed_disable_tracking(PyObject *self, PyObject *args)
{
    int ret = -1;
    int pid;

    if (!PyArg_ParseTuple(args, "i", &pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_TRACKING_DISABLE, &pid);
    return Py_BuildValue("i", ret);
}

static PyObject *severed_change_mapping(PyObject *self, PyObject *args)
{
    int ret = -1;
    ma_mapping_change_param_t mapping_change_param;

    if (!PyArg_ParseTuple(args, "KKi", &mapping_change_param.gfn1, &mapping_change_param.gfn2, &mapping_change_param.pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_MAPPING_CHANGE, &mapping_change_param);
    return Py_BuildValue("i", ret);
}

static PyObject *severed_change_mapping_direct(PyObject *self, PyObject *args)
{
    int ret = -1;
    mapping_change_param2_t mapping_change_param;

    printf("In severed_change_mapping_direct\n");

    if (!PyArg_ParseTuple(args, "KKi", &mapping_change_param.gfn, &mapping_change_param.pfn, &mapping_change_param.pid)) {
        PyErr_Format(
            PyExc_Exception,
            "Function arguments are of wrong type"
        );
        return NULL;
    }

    ret = __severed_kvmioctl(KVM_MAPPING_CHANGE_DIRECT, &mapping_change_param);
    return Py_BuildValue("i", ret);
}
